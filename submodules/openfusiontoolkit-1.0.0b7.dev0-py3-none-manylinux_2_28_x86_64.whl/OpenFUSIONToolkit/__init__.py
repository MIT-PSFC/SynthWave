#------------------------------------------------------------------------------
# Flexible Unstructured Simulation Infrastructure with Open Numerics (Open FUSION Toolkit)
#
# SPDX-License-Identifier: LGPL-3.0-only
#------------------------------------------------------------------------------
'''! Python interface for Open FUSION Toolkit

@authors Chris Hansen
@date May 2023
@ingroup doxy_oft_python
'''
from ._core import OFT_env

__all__ = ["OFT_env"]
__version__ = '1.0.0-beta7.dev'
